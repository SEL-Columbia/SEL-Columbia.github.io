function[cop_uv cop_puv] = coptf(FOR, capacity, n)
    cop = 1:(2^n);
    cop_p = 1:(2^n); 
    for k=0:(2^n-1), 
        m = k;
        l = floor(m/2^(n-1));
        binary_n = l;
        for i=(n-2):(-1):0,
            m = m-l*2^(i+1);
            l = floor(m/2^(i));
            binary_n = [binary_n l]; 
        end 
        cop(k+1) = sum(capacity*binary_n');
        cop_p(k+1)= prod(FOR(binary_n==1))*prod(1-FOR(binary_n==0));      
    end 
    cop_uv = unique(cop);
    sizeuv = size(cop_uv);
    cop_puv =1:sizeuv(2);
    for i=1:sizeuv(2),
        cop_puv(i) = sum(cop_p((cop==cop_uv(i))));
    end 
end
