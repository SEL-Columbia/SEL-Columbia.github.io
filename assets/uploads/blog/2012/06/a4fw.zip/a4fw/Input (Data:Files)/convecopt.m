
%% CVX Solver for Wind Power Optimization Problem, Version 1.0


function [x_opt] = convecopt(A, lambda, y_min)

budget = 1;
sizeA = size(A);
n = sizeA(2);

%% cvx code
cvx_begin
variable x_opt(n);
y = A*x_opt;
maximize(sum(y)-lambda*sum( (y - mean(y)).^2 ))
subject to
y >= y_min;
0 <= x_opt;
x_opt <= 1;
sum(x_opt) <= budget;
cvx_end


% total power
totalpower = sum(y);
%storage benefit

end












