function[cdfvalue] = cdfload(x)
   if(x<1.5)
       cdfvalue=1.2 - exp(-x);
   end
   if(x==1.5)
    cdfvalue=1;
   end
end